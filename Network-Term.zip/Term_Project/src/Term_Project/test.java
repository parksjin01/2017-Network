package Term_Project;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.*;
import java.util.*;

import org.apache.tika.Tika;



public class test {
   
   public static void main(String[] args) throws ClassNotFoundException, SQLException {
	   File file = new File("/Users/Knight/Desktop/01.mp4");
	   Tika t = new Tika();
	   try {
		String format = t.detect(file);
		System.out.println(format);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	   
   }

}